class AppConstant {
  static const poppinsFont = "Poppins";
}
