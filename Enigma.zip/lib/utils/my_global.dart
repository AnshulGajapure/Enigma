// import 'dart:developer';
// import 'dart:io';
// import 'package:intl/intl.dart';
// import 'dart:math' as math;
// import 'package:url_launcher/url_launcher_string.dart';
//
//
// class MyGlobal{
//
//   ///
//   ///
//   ///
//   static String checkNullData(String? data){
//     if(data == null){
//       return '';
//     }else{
//       return data;
//     }
//   }
//
//
//   ///
//   ///
//   ///
//   static String convertServerDate(String? date){
//     log('Server-Date $date');
//     DateTime parseDate = DateTime.parse(date!);
//     DateTime dateTime = DateTime(parseDate.year, parseDate.month, parseDate.day, 00, 00, 00);
//     String formattedDate = DateFormat('dd MMM yyyy').format(dateTime);
//     return formattedDate;
//   }
//
//
//
//   ///
//   ///
//   ///
//   static String convertServeTime(String? date){
//     log('Server-Date $date');
//     DateTime parseDate = DateTime.parse(date!);
//     DateTime dateTime = DateTime(parseDate.year, parseDate.month, parseDate.day, parseDate.hour, parseDate.minute, parseDate.second);
//     String formattedDate = DateFormat('hh:mm a').format(dateTime);
//     return formattedDate;
//   }
//
//   ///
//   ///
//   ///
//   static Future<String> getFileSize(String filepath, int decimals) async {
//     var file = File(filepath);
//     int bytes = await file.length();
//     if (bytes <= 0) return "0 B";
//     const suffixes = ["byte", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
//     var i = (math.log(bytes) / math.log(1024)).floor();
//     return '${(bytes / math.pow(1024, i)).toStringAsFixed(decimals)} ${suffixes[i]}';
//   }
//
//   ///
//   ///
//   /// use to open drive link of events on web
//   static openIntoWeb(String url) async{
//     if (await canLaunchUrlString(url)) {
//       await launchUrlString(url);
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//
//   ///
//   ///
//   ///
//   static String timeAgo({bool numericDates = true, required String dbDateTime}) {
//
//
//     final currentDateTime = DateTime.now();
//     final difference = currentDateTime.difference(DateTime.parse(dbDateTime));
//
//
//     log('DB_DATE_TIME -----   ${dbDateTime}');
//
//
//     if ((difference.inDays / 7).floor() >= 1) {
//       return (numericDates) ? '1 week ago' : 'Last week';
//     } else if (difference.inDays >= 2) {
//       return '${difference.inDays} days ago';
//     } else if (difference.inDays >= 1) {
//       return (numericDates) ? '1 day ago' : 'Yesterday';
//     } else if (difference.inHours >= 2) {
//       return '${difference.inHours} hours ago';
//     } else if (difference.inHours >= 1) {
//       return (numericDates) ? '1 hour ago' : 'An hour ago';
//     } else if (difference.inMinutes >= 2) {
//       return '${difference.inMinutes} minutes ago';
//     } else if (difference.inMinutes >= 1) {
//       return (numericDates) ? '1 minute ago' : 'A minute ago';
//     } else if (difference.inSeconds >= 3) {
//       return '${difference.inSeconds} seconds ago';
//     } else {
//       return 'Just now';
//     }
//   }
//
//
//
// }
