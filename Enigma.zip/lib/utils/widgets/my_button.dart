// import 'package:flutter/material.dart';
// import 'package:vidyamate/resources/my_colors.dart';
//
// Widget myButton({
//   required context,
//   required VoidCallback? onTap,
//   required String? btnName,
// }) {
//   return Container(
//     width: MediaQuery.of(context).size.width,
//     height: 50.0,
//     child: MaterialButton(
//         shape: StadiumBorder(),
//         textColor: Colors.white,
//         color: MyColor.primaryColor,
//         splashColor: Color.fromARGB(255, 64, 128, 238),
//         disabledColor: MyColor.primaryColor,
//         onPressed: onTap!,
//         elevation: 3.0,
//         child: GestureDetector(
//           onTap: onTap,
//           child: Text(
//             btnName!,
//             textAlign: TextAlign.center,
//             style: const TextStyle(
//               fontFamily: 'RobotoMedium',
//               color: Colors.white,
//               fontSize: 18.0,
//               //fontWeight: FontWeight.bold,
//             ),
//           ),
//         )),
//   );
// }
