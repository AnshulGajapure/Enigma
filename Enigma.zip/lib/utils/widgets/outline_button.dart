// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:qatarcleanz_driver/resources/my_colors.dart';

// Widget mySmallButton({
//   required VoidCallback? onTap,
//   required String? btnName,
//   required double? btnWidth,
// }) {
//   return Container(
//     child: UnicornOutlineButton(
//                   strokeWidth: 2,
//                   radius: 24,
//                   gradient: LinearGradient(colors: [Colors.black, Colors.redAccent]),
//                   child: Text('OMG', style: TextStyle(fontSize: 16)),
//                   onPressed: () {},
//                 ),
//   );
// }


