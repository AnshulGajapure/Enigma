import 'package:enigma/resources/my_colors.dart';
import 'package:enigma/utils/colors_util.dart';
import 'package:flutter/material.dart';

PreferredSizeWidget myAppbar({
  required String title,
}) {
  return PreferredSize(
    preferredSize: const Size.fromHeight(100.0), // Set height for long AppBar
    child: AppBar(
      automaticallyImplyLeading: false,
      elevation: 0.0,
      backgroundColor: MyColor.BackgroundColor,
      flexibleSpace: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15.0),
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 26,
                    color: HexColor("#171717"),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      centerTitle: true,
    ),
  );
}
