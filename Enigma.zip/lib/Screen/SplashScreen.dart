import 'package:enigma/Screen/Login.dart';
import 'package:enigma/resources/my_assets.dart';
import 'package:flutter/material.dart';

import '../resources/my_colors.dart';

class splashscreen extends StatefulWidget {
  const splashscreen({super.key});

  @override
  State<splashscreen> createState() => _splashscreenState();
}

class _splashscreenState extends State<splashscreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Login()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Padding(
        padding: EdgeInsets.all(25.0),
        child: Center(
          child: Image(image: appLogo),
        ),
      ),
    );
  }
}
