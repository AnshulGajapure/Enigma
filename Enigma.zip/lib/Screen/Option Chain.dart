import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_colors.dart';

class OptionChainTab extends StatefulWidget {
  OptionChainTab({super.key, required this.tabController});

  TabController tabController;

  @override
  State<OptionChainTab> createState() => _OptionChainTabState();
}

class _OptionChainTabState extends State<OptionChainTab>
    with SingleTickerProviderStateMixin {
  final List<String> labels = [
    "All",
    "Nifty",
    "Banknifty",
    "Finifty",
    "Midcapnifty"
  ];

  final List<Map<String, String>> stockData = [
    {
      "name": "DRREDDY",
      "exchange": "NSE",
      "price": "1276.70",
      "change": "+27.90 (+2.18)"
    },
    {
      "name": "TCS",
      "exchange": "NSE",
      "price": "3401.50",
      "change": "-10.50 (-0.31)"
    },
    {
      "name": "INFY",
      "exchange": "NSE",
      "price": "1570.25",
      "change": "+5.25 (+0.33)"
    },
    {
      "name": "HDFCBANK",
      "exchange": "NSE",
      "price": "1652.30",
      "change": "+12.50 (+0.76)"
    },
    {
      "name": "RELIANCE",
      "exchange": "NSE",
      "price": "2510.15",
      "change": "-20.30 (-0.80)"
    },
  ];

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: labels.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    final filteredData = (int index) {
      return stockData;
    };

    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 5),
        child: Column(
          children: [
            TabBar(
              dividerColor: Colors.transparent,
              controller: widget.tabController,
              indicatorColor: MyColor.Tabbarlable,
              indicatorPadding: EdgeInsets.symmetric(vertical: 10.0),
              labelStyle: TextStyle(
                fontSize: size.height * 0.016,
                fontFamily: AppConstant.poppinsFont,
              ),
              labelColor: MyColor.Tabbarlable,
              unselectedLabelColor: Colors.black,
              labelPadding: EdgeInsets.symmetric(horizontal: 8.0),
              isScrollable: true,
              tabs: labels.map((label) {
                return Tab(
                  text: label,
                );
              }).toList(),
            ),
            Expanded(
              child: TabBarView(
                controller: widget.tabController,
                children: List.generate(labels.length, (index) {
                  return Container(
                    width: size.width,
                    decoration: BoxDecoration(
                      color: MyColor.EquityTabColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListView.builder(
                      itemCount: filteredData(index).length,
                      itemBuilder: (context, index) {
                        final stock = filteredData(index)[index];
                        return Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10.0, vertical: 5.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        stock["name"]!,
                                        style: TextStyle(
                                            fontFamily:
                                                AppConstant.poppinsFont),
                                      ),
                                      Text(
                                        stock["exchange"]!,
                                        style: TextStyle(
                                            fontSize: size.height * 0.015,
                                            fontFamily:
                                                AppConstant.poppinsFont),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        stock["price"]!,
                                        style: TextStyle(
                                            fontFamily:
                                                AppConstant.poppinsFont),
                                      ),
                                      Text(
                                        stock["change"]!,
                                        style: TextStyle(
                                          fontSize: size.height * 0.015,
                                          fontFamily: AppConstant.poppinsFont,
                                          color:
                                              stock["change"]!.startsWith("+")
                                                  ? MyColor.IndexText
                                                  : MyColor.IndexText,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            if (index < filteredData(index).length - 1)
                              Divider(),
                          ],
                        );
                      },
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
