import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_assets.dart';
import 'EquityTab.dart';
import 'FNOTab.dart';
import 'Option Chain.dart';

class Equity extends StatefulWidget {
  Equity({super.key});

  @override
  State<Equity> createState() => _EquityState();
}

late Size size;

class _EquityState extends State<Equity> with TickerProviderStateMixin {
  late TabController _tabController;
  late TabController _fnoTabController;
  late TabController _optionChainTabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _fnoTabController = TabController(length: 6, vsync: this);
    _optionChainTabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _fnoTabController.dispose();
    _optionChainTabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Container(
          width: size.width,
          height: size.height * 0.08,
          color: MyColor.Equatyappbar,
          child: Padding(
            padding: EdgeInsets.only(top: 15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Index("NIFTY", "25369.32", "-332.25", MyColor.Equitytext),
                Column(
                  children: [
                    Container(
                      height: size.height * 0.04,
                      child: VerticalDivider(
                        color: Colors.black,
                        thickness: 2,
                        width: 30,
                      ),
                    ),
                  ],
                ),
                Index("BANKNIFTY", "25369.32", "-332.25", MyColor.Equitytext),
              ],
            ),
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(100.0),
          child: Column(
            children: [
              Padding(
                padding:
                    EdgeInsets.only(top: 10, bottom: 10, left: 15, right: 15),
                child: Container(
                  height: size.height * 0.05,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Search Stocks ....",
                      hintStyle: TextStyle(
                          fontSize: size.height * 0.017,
                          color: MyColor.EquatysearchText,
                          fontFamily: AppConstant.poppinsFont),
                      prefixIcon: Padding(
                        padding: EdgeInsets.all(9.0),
                        child: Image(image: searchlogo),
                      ),
                      suffixIcon: Padding(
                        padding: EdgeInsets.all(9.0),
                        child: Image(image: searchmenulogo),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide:
                            BorderSide(color: MyColor.Searchbar, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide:
                            BorderSide(color: MyColor.Searchbar, width: 1.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide:
                            BorderSide(color: MyColor.Searchbar, width: 2.0),
                      ),
                      fillColor: Colors.white,
                    ),
                  ),
                ),
              ),
              Container(
                height: size.height * 0.05,
                margin: EdgeInsets.only(right: 15, left: 15),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: MyColor.EquityTabbar),
                child: TabBar(
                  controller: _tabController,
                  unselectedLabelStyle: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.grey),
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  indicatorPadding: EdgeInsets.symmetric(vertical: 4.0),
                  indicatorColor: Colors.transparent,
                  dividerColor: Colors.transparent,
                  labelColor: MyColor.EquityTabbarText,
                  labelStyle: TextStyle(
                      fontSize: size.height * 0.015,
                      fontWeight: FontWeight.bold,
                      fontFamily: AppConstant.poppinsFont),
                  onTap: (index) {
                    setState(() {
                      _tabController.index = index;
                    });
                  },
                  tabs: [
                    Tab(text: "Equity"),
                    Tab(text: "FNO"),
                    Tab(text: "Option Chain"),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        physics: NeverScrollableScrollPhysics(),
        children: [
          EquityTab(),
          FNOTab(
            tabController: _fnoTabController,
          ),
          OptionChainTab(
            tabController: _fnoTabController,
          ),
        ],
      ),
    );
  }

  Widget Index(String title, String value, String change, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: MyColor.TextColor,
            fontSize: size.height * 0.015,
            fontWeight: FontWeight.bold,
            fontFamily: AppConstant.poppinsFont,
          ),
        ),
        SizedBox(height: size.height * 0.01),
        Row(
          children: [
            Text(
              value,
              style: TextStyle(
                color: MyColor.Equitytext,
                fontSize: size.height * 0.015,
                fontFamily: AppConstant.poppinsFont,
              ),
            ),
            SizedBox(width: 5),
            Text(
              "($change)",
              style: TextStyle(
                color: color,
                fontSize: size.height * 0.015,
                fontFamily: AppConstant.poppinsFont,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
