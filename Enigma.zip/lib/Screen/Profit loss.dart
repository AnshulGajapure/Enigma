import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import 'Trade.dart';

class Profitloss extends StatefulWidget {
  const Profitloss({super.key});

  @override
  State<Profitloss> createState() => _ProfitlossState();
}

late Size size;

class _ProfitlossState extends State<Profitloss> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(right: 20, left: 20, top: 65),
            child: Container(
              height: size.height * 0.07,
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: MyColor.ContainerColor,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: Text(
                      "Net Profit & Loss",
                      style: TextStyle(
                        fontSize: size.height * 0.016,

                        shadows: [
                          Shadow(color: Colors.black, offset: Offset(0, -5))
                        ],
                        color: Colors.transparent,
                        // fontWeight: FontWeight.bold,

                        fontWeight: FontWeight.w500,
                        fontFamily: AppConstant.poppinsFont,
                        decoration: TextDecoration.underline,
                        decorationStyle: TextDecorationStyle.dashed,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: size.width * 0.01,
                  ),
                  Text(
                    ":",
                    style: TextStyle(
                      fontSize: size.height * 0.016,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                      fontFamily: AppConstant.poppinsFont,
                    ),
                  ),
                  SizedBox(
                    width: size.width * 0.01,
                  ),
                  Row(
                    children: [
                      Text(
                        "-",
                        style: TextStyle(
                          fontSize: size.height * 0.016,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeRedText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Icon(
                        Icons.currency_rupee,
                        color: MyColor.TradeRedText,
                        size: size.height * 0.02,
                      ),
                      Text(
                        '1.00',
                        style: TextStyle(
                          fontSize: size.height * 0.016,
                          // fontWeight: FontWeight.bold,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeRedText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      SizedBox(
                        width: size.width * 0.001,
                      ),
                      Text(
                        '(-0.08%)',
                        style: TextStyle(
                          fontSize: size.height * 0.016,
                          // fontWeight: FontWeight.bold,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeRedText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 30.0, left: 25, right: 25),
            child: Container(
              width: size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Trade Details",
                    style: TextStyle(
                      fontSize: size.height * 0.017,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontFamily: AppConstant.poppinsFont,
                    ),
                  ),
                  SizedBox(
                    height: size.height * 0.05,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Instrument",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeBlackText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "CIPLA",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // fontWeight: FontWeight.bold,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Status",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          color: MyColor.TradeBlackText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "Active",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Quantity",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          color: MyColor.TradeBlackText,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "+25",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "LTP",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeBlackText,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            "360.00",
                            style: TextStyle(
                              fontSize: size.height * 0.017,
                              fontWeight: FontWeight.w500,
                              // color: Colors.black,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                          SizedBox(
                            width: size.width * 0.01,
                          ),
                          Text(
                            "(+1.04%)",
                            style: TextStyle(
                              fontSize: size.height * 0.017,
                              // fontWeight: FontWeight.bold,
                              color: MyColor.IndexText,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Stoploss",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          color: MyColor.TradeBlackText,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "--",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          // fontWeight: FontWeight.bold,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Target",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          color: MyColor.TradeBlackText,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "--",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          // fontWeight: FontWeight.bold,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Divider(),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Validity Till",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          color: MyColor.TradeBlackText,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "23 Dec 24, 3.20 pm",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Margin Used",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          color: MyColor.TradeBlackText,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "1222.95",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Est. Charges",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          height: 1.5,
                          shadows: [
                            Shadow(color: Colors.black, offset: Offset(0, -5))
                          ],
                          color: Colors.transparent,
                          fontWeight: FontWeight.w500,

                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                          decoration: TextDecoration.underline,
                          decorationStyle: TextDecorationStyle.dashed,
                        ),
                      ),
                      Text(
                        "N.A",
                        style: TextStyle(
                          fontSize: size.height * 0.017,
                          fontWeight: FontWeight.w500,
                          // color: Colors.black,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.03,
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: size.height * 0.06,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: MyColor.ButtonColor,
                        // Filled button color
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(11),
                        ),
                        elevation: 0, // Optional: Remove shadow if not needed
                      ),
                      onPressed: () {
                        // if (_formKey.currentState!.validate()) {
                        //   ScaffoldMessenger.of(context).showSnackBar(
                        //     SnackBar(content: Text('Processing...')),
                        //   );
                        // }
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Trade()),
                        );
                      },
                      child: Text(
                        "Exit",
                        style: TextStyle(
                          fontSize: size.height * 0.022,
                          color: Colors.white,
                          fontFamily: "Poppins",
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
