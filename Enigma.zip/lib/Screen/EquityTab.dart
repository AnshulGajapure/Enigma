import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_colors.dart';

class EquityTab extends StatefulWidget {
  EquityTab({super.key});

  @override
  State<EquityTab> createState() => _EquityTabState();
}

late Size size;
String? selectedText;

class _EquityTabState extends State<EquityTab> {
  final List<Map<String, String>> stockData = [
    {
      "name": "DRREDDY",
      "exchange": "NSE",
      "price": "1276.70",
      "change": "+27.90 (+2.18)"
    },
    {
      "name": "TCS",
      "exchange": "NSE",
      "price": "3401.50",
      "change": "-10.50 (-0.31)"
    },
    {
      "name": "INFY",
      "exchange": "NSE",
      "price": "1570.25",
      "change": "+5.25 (+0.33)"
    },
    {
      "name": "HDFCBANK",
      "exchange": "NSE",
      "price": "1652.30",
      "change": "+12.50 (+0.76)"
    },
    {
      "name": "RELIANCE",
      "exchange": "NSE",
      "price": "2510.15",
      "change": "-20.30 (-0.80)"
    },
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 5),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: size.width,
                decoration: BoxDecoration(
                    color: MyColor.EquityTabColor,
                    borderRadius: BorderRadius.circular(10)),
                child: ListView.builder(
                  itemCount: stockData.length,
                  itemBuilder: (context, index) {
                    final stock = stockData[index];
                    return Column(
                      children: [
                        Padding(
                          padding:
                              EdgeInsets.only(left: 10.0, right: 10.0, top: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "DRREDDY",
                                    style: TextStyle(
                                        fontFamily: AppConstant.poppinsFont),
                                  ),
                                  Text(
                                    "NSE",
                                    style: TextStyle(
                                        fontSize: size.height * 0.015,
                                        fontFamily: AppConstant.poppinsFont),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "1276.70",
                                    style: TextStyle(
                                        fontFamily: AppConstant.poppinsFont),
                                  ),
                                  Text("+27.90 (+2.18)",
                                      style: TextStyle(
                                          fontSize: size.height * 0.015,
                                          fontFamily: AppConstant.poppinsFont,
                                          color: MyColor.EquitylistText)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        if (index < stockData.length - 1) Divider(),
                      ],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
