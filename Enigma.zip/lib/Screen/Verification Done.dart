import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/my_assets.dart';

class VerificationDone extends StatefulWidget {
  VerificationDone({super.key});

  @override
  State<VerificationDone> createState() => _VerificationDoneState();
}

late Size size;

class _VerificationDoneState extends State<VerificationDone> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.VerificationDone,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image(
              image: verificationdonelogo,
              width: 200,
              height: 200,
            ),
          ),
          SizedBox(
            height: size.height * 0.03,
          ),
          Text(
            "Password has been",
            style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontFamily: "Poppins",
            ),
          ),
          Text(
            "Changed Successfully",
            style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontFamily: "Poppins",
            ),
          ),
        ],
      ),
    );
  }
}
