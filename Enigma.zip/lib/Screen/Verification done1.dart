import 'package:enigma/utils/colors_util.dart';
import 'package:flutter/material.dart';

import '../resources/my_assets.dart';

class verificationdone extends StatefulWidget {
  verificationdone({super.key});

  @override
  State<verificationdone> createState() => _verificationdoneState();
}

class _verificationdoneState extends State<verificationdone> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HexColor("#007B5D"),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image(
              image: verificationdonelogo,
              width: 200,
              height: 200,
            ),
          ),
          Text(
            "OTP verified",
            style: TextStyle(
              fontSize: 25,
              color: Colors.white,
              fontFamily: "Poppins",
            ),
          ),
          Text(
            "Your mobile number has been verified",
            style: TextStyle(
              fontSize: 13,
              color: Colors.white,
              fontFamily: "Poppins",
            ),
          ),
          Text(
            "successfully",
            style: TextStyle(
              fontSize: 13,
              color: Colors.white,
              fontFamily: "Poppins",
            ),
          )
        ],
      ),
    );
  }
}
