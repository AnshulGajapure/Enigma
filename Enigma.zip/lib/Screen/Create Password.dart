import 'package:flutter/material.dart';

import '../resources/my_colors.dart';
import '../utils/my_appbar.dart';
import 'Verification Done.dart';

class CreatePassword extends StatefulWidget {
  CreatePassword({super.key});

  @override
  State<CreatePassword> createState() => _CreatePasswordState();
}

late Size size;
bool isPasswordHidden = true;
bool isCreatePasswordHidden = true;
TextEditingController passwordController = TextEditingController();
TextEditingController confirmPasswordController = TextEditingController();

class _CreatePasswordState extends State<CreatePassword> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      appBar: myAppbar(title: 'Create Password'),
      body: Padding(
        padding: EdgeInsets.only(left: 15.0, right: 15, top: 30),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              text("New Password"),
              SizedBox(
                height: size.height * 0.01,
              ),
              Container(
                height: size.height * 0.055,
                child: TextFormField(
                  controller: passwordController,
                  obscureText: isPasswordHidden,
                  decoration: InputDecoration(
                    suffixIcon: IconButton(
                      icon: Icon(
                        isPasswordHidden
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Color(0xff838383),
                        size: size.height * 0.02,
                      ),
                      onPressed: () {
                        setState(() {
                          isPasswordHidden = !isPasswordHidden;
                        });
                      },
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: MyColor.BorderColor, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                        color: MyColor.BorderColor,
                      ),
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                    hintText: "Please Enter password",
                    hintStyle: TextStyle(
                      fontSize: 14,
                      fontFamily: "Poppins",
                      color: MyColor.HintColor,
                    ),
                  ),
                  keyboardType: TextInputType.visiblePassword,
                ),
              ),
              SizedBox(
                height: size.height * 0.03,
              ),
              text("Confirm Password"),
              SizedBox(
                height: size.height * 0.01,
              ),
              Container(
                height: size.height * 0.055,
                child: TextFormField(
                  controller: confirmPasswordController,
                  obscureText: isCreatePasswordHidden,
                  decoration: InputDecoration(
                    suffixIcon: IconButton(
                      icon: Icon(
                        isCreatePasswordHidden
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Color(0xff838383),
                        size: 19,
                      ),
                      onPressed: () {
                        setState(() {
                          isCreatePasswordHidden = !isCreatePasswordHidden;
                        });
                      },
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: MyColor.BorderColor, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                        color: MyColor.BorderColor,
                      ),
                    ),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                    hintText: "Please Enter password",
                    hintStyle: TextStyle(
                      fontSize: 14,
                      fontFamily: "Poppins",
                      color: MyColor.HintColor,
                    ),
                  ),
                  keyboardType: TextInputType.visiblePassword,
                ),
              ),
              SizedBox(
                height: size.height * 0.25,
              ),
              SizedBox(
                width: double.infinity,
                height: size.height * 0.06,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MyColor.ButtonColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(11),
                    ),
                    elevation: 0,
                  ),
                  onPressed: () {
                    // Add your submit logic here
                    String password = passwordController.text;
                    String confirmPassword = confirmPasswordController.text;

                    if (password == confirmPassword) {
                      // Passwords match - proceed with the logic
                    } else {
                      // Passwords do not match - show error or feedback to user
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => VerificationDone()),
                    );
                  },
                  child: Text(
                    "Submit",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontFamily: "Poppins",
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget text(String? text) {
    return Text(
      text ?? '',
      style: TextStyle(
        fontFamily: "Poppins",
        color: MyColor.TextColor,
        fontSize: size.height * 0.020,
      ),
    );
  }
}
