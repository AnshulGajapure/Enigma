import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/app_constants.dart';

class EditProfile extends StatefulWidget {
  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  TextEditingController currentPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  bool isNewPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  @override
  void dispose() {
    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final fontSize = size.height * 0.02;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.black,
            size: fontSize,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              "Change Password",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w600,
                fontSize: fontSize, // Use responsive font size
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: size.height * 0.02),
              Textfield(
                label: "Current Password",
                placeholder: "Current Password",
                controller: currentPasswordController,
                fontSize: fontSize,
              ),
              SizedBox(height: size.height * 0.02),
              PasswordTextField(
                label: "Create New Password",
                placeholder: "New Password",
                controller: newPasswordController,
                isPasswordVisible: isNewPasswordVisible,
                toggleVisibility: () {
                  setState(() {
                    isNewPasswordVisible = !isNewPasswordVisible;
                  });
                },
                fontSize: fontSize,
              ),
              SizedBox(height: size.height * 0.02),
              PasswordTextField(
                label: "Confirm New Password",
                placeholder: "Confirm New Password",
                controller: confirmPasswordController,
                isPasswordVisible: isConfirmPasswordVisible,
                toggleVisibility: () {
                  setState(() {
                    isConfirmPasswordVisible = !isConfirmPasswordVisible;
                  });
                },
                fontSize: fontSize,
              ),
              SizedBox(height: size.height * 0.3),
              Container(
                padding: EdgeInsets.only(left: 10, right: 10),
                width: size.width,
                child: ElevatedButton(
                  onPressed: () {
                    String currentPassword = currentPasswordController.text;
                    String newPassword = newPasswordController.text;
                    String confirmPassword = confirmPasswordController.text;
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MyColor.ButtonColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                  ),
                  child: Text(
                    "Change Password",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: fontSize, // Use responsive font size
                      fontWeight: FontWeight.w500,
                      fontFamily: AppConstant.poppinsFont,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget Textfield({
    required String label,
    required String placeholder,
    required TextEditingController controller,
    required double fontSize,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: fontSize, // Use responsive font size
            fontFamily: AppConstant.poppinsFont,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        Container(
          height: MediaQuery.of(context).size.height * 0.065,
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: placeholder,
              hintStyle: TextStyle(
                fontFamily: AppConstant.poppinsFont,
                fontSize: fontSize * 0.8,
                // Slightly smaller for the placeholder
                color: Colors.black54,
              ),
              contentPadding: EdgeInsets.symmetric(vertical: 9, horizontal: 12),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: MyColor.Textfiled),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: MyColor.Textfiled,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class PasswordTextField extends StatelessWidget {
  final String label;
  final String placeholder;
  final TextEditingController controller;
  final bool isPasswordVisible;
  final VoidCallback toggleVisibility;
  final double fontSize;

  PasswordTextField({
    required this.label,
    required this.placeholder,
    required this.controller,
    required this.isPasswordVisible,
    required this.toggleVisibility,
    required this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: fontSize,
            fontFamily: AppConstant.poppinsFont,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        Container(
          height: MediaQuery.of(context).size.height * 0.065,
          child: TextField(
            controller: controller,
            obscureText: !isPasswordVisible,
            decoration: InputDecoration(
              hintText: placeholder,
              hintStyle: TextStyle(
                fontFamily: AppConstant.poppinsFont,
                fontSize: fontSize * 0.8,
                color: Colors.black54,
              ),
              contentPadding: EdgeInsets.symmetric(vertical: 9, horizontal: 12),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: MyColor.Textfiled),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: MyColor.Textfiled,
                ),
              ),
              suffixIcon: IconButton(
                icon: Icon(
                  isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                  color: Colors.black54,
                  size: fontSize,
                ),
                onPressed: toggleVisibility,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
