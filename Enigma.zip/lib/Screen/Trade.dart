import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_colors.dart';

class Trade extends StatefulWidget {
  Trade({super.key});

  @override
  State<Trade> createState() => _TradeState();
}

class _TradeState extends State<Trade> {
  late Size size;

  final List<Map<String, String>> _tradeList = [
    {
      "name": "DRREDDY",
      "qty": "12",
      "avg": "1267.63",
      "invested": "19008.23",
      "percent": "+4.43%",
      "change": "+27.90 (+2.18)",
      "ltp": "890.00",
      "ltpChange": "(+1.04%)"
    },
    {
      "name": "CIPLA",
      "qty": "5",
      "avg": "3245.50",
      "invested": "16227.50",
      "percent": "+1.20%",
      "change": "+50.00 (+1.55)",
      "ltp": "3450.00",
      "ltpChange": "(+1.60%)"
    },
  ];

  void addTrade(Map<String, String> newTrade) {
    setState(() {
      _tradeList.add(newTrade);
    });
  }

  void removeTrade(int index) {
    setState(() {
      _tradeList.removeAt(index);
    });
  }

  void updateTrade(int index, Map<String, String> updatedTrade) {
    setState(() {
      _tradeList[index] = updatedTrade;
    });
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 40),
          child: Column(
            children: [
              Container(
                height: size.height * 0.08,
                decoration: BoxDecoration(color: MyColor.TradeColor),
                padding: EdgeInsets.all(11.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.currency_rupee,
                              color: Colors.black,
                              size: size.height * 0.017,
                              weight: 5,
                            ),
                            Text(
                              '9,86,798.59',
                              style: TextStyle(
                                fontSize: size.height * 0.018,
                                fontWeight: FontWeight.w800,
                                fontFamily: AppConstant.poppinsFont,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'Total Portfolio',
                          style: TextStyle(
                            fontFamily: AppConstant.poppinsFont,
                            fontWeight: FontWeight.w500,
                            fontSize: size.height * 0.016,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.currency_rupee,
                              color: MyColor.IndexText,
                              size: size.height * 0.023,
                            ),
                            Text(
                              '1.50',
                              style: TextStyle(
                                fontSize: size.height * 0.018,
                                fontWeight: FontWeight.w600,
                                color: MyColor.IndexText,
                                fontFamily: AppConstant.poppinsFont,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'Unrealised P&L',
                          style: TextStyle(
                            fontFamily: AppConstant.poppinsFont,
                            fontSize: size.height * 0.016,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Container(
                  height: size.height * 0.1,
                  decoration: BoxDecoration(
                    color: MyColor.ContainerColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: EdgeInsets.all(13.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Available Margin',
                            style: TextStyle(
                              fontSize: size.height * 0.017,
                              fontWeight: FontWeight.w500,
                              color: MyColor.TradeTextColor,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Invested Margin',
                            style: TextStyle(
                              fontSize: size.height * 0.017,
                              fontWeight: FontWeight.w500,
                              color: MyColor.TradeTextColor,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.currency_rupee,
                                color: Colors.black,
                                size: size.height * 0.025,
                              ),
                              Text(
                                '9,86,798.59',
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: AppConstant.poppinsFont,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(
                                Icons.currency_rupee,
                                color: Colors.black,
                                size: size.height * 0.025,
                              ),
                              Text(
                                '1,270.60',
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: AppConstant.poppinsFont,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),
              // List of trades
              Container(
                height: size.height * 0.7,
                decoration:
                    BoxDecoration(color: MyColor.TradeListContainerColor),
                child: ListView.builder(
                  padding: EdgeInsets.all(13.0),
                  itemCount: _tradeList.length,
                  itemBuilder: (context, index) {
                    final trade = _tradeList[index];
                    return Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 30.0, right: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    trade["name"]!,
                                    style: TextStyle(
                                      fontSize: size.height * 0.017,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.black,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.001),
                                  Text(
                                    "Qty. ${trade["qty"]}   Avg. ${trade["avg"]}",
                                    style: TextStyle(
                                      fontSize: size.height * 0.015,
                                      color: Colors.black,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.001),
                                  Text(
                                    "Invested ${trade["invested"]}",
                                    style: TextStyle(
                                      fontSize: size.height * 0.015,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    trade["percent"]!,
                                    style: TextStyle(
                                      fontSize: size.height * 0.015,
                                      color: MyColor.IndexText,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.001),
                                  Text(
                                    trade["change"]!,
                                    style: TextStyle(
                                      fontSize: size.height * 0.015,
                                      color: MyColor.IndexText,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.001),
                                  Row(
                                    children: [
                                      Text(
                                        "LTP ${trade["ltp"]}",
                                        style: TextStyle(
                                          fontSize: size.height * 0.015,
                                          color: Colors.black,
                                          fontFamily: AppConstant.poppinsFont,
                                        ),
                                      ),
                                      Text(
                                        " ${trade["ltpChange"]}",
                                        style: TextStyle(
                                          fontSize: size.height * 0.015,
                                          color: MyColor.IndexText,
                                          fontFamily: AppConstant.poppinsFont,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Divider(
                          height: 20,
                          thickness: 1,
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
