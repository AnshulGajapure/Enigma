import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../resources/my_colors.dart';
import '../utils/my_appbar.dart';
import 'Forgot Password.dart';
import 'Register.dart';

class Login extends StatefulWidget {
  Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

late Size size;

class _LoginState extends State<Login> {
  String pNumber = '';

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      appBar: myAppbar(title: 'Account Login'),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              text("Mobile number"),
              SizedBox(
                height: 5,
              ),
              IntlPhoneField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor.BorderColor,
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 4.0, horizontal: 10.0),
                  hintText: "Enter Mobile Number",
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                initialCountryCode: 'IN',
                onChanged: (phone) {
                  pNumber = phone.completeNumber;
                },
              ),
              SizedBox(
                height: 30,
              ),
              text("Password"),
              SizedBox(
                height: 5,
              ),
              TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  suffixIcon: Icon(
                    Icons.visibility_off_outlined,
                    color: Color(0xff838383),
                    size: 19,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor.BorderColor,
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 4.0, horizontal: 10.0),
                  hintText: "Please enter password",
                  hintStyle: TextStyle(
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                    fontSize: 14,
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ForgotPassword()),
                    );
                  },
                  child: Text(
                    "Forgot Password?",
                    style: TextStyle(
                      color: MyColor.TextLinkColor,
                      fontFamily: "Poppins",
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: size.height * 0.15,
              ),
              SizedBox(
                width: double.infinity,
                height: size.height * 0.06,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: MyColor.ButtonColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(11),
                    ),
                    elevation: 0,
                  ),
                  // onPressed: () {},
                  onPressed: () {
                    if (pNumber.isNotEmpty) {
                      Fluttertoast.showToast(
                        msg: "Phone Number: $pNumber",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.black,
                        textColor: Colors.white,
                        fontSize: 16.0,
                      );
                    } else {
                      Fluttertoast.showToast(
                        msg: "Please enter your number",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.black,
                        textColor: Colors.white,
                        fontSize: 16.0,
                      );
                    }
                  },
                  child: Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontFamily: "Poppins",
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: size.height * 0.02,
              ),
              Center(
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => registerscreen()),
                    );
                  },
                  child: Text(
                    "Register now",
                    style: TextStyle(
                      fontSize: 17,
                      fontFamily: "Poppins",
                      fontWeight: FontWeight.w500,
                      color: MyColor.TextColor,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget text(String? text) {
    return Text(
      text ?? '',
      style: TextStyle(
          fontFamily: "Poppins", color: MyColor.TextColor, fontSize: 16),
    );
  }
}
