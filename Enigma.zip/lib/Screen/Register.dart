import 'package:flutter/material.dart';

import '../resources/my_colors.dart';
import '../utils/my_appbar.dart';
import 'OTP Verificaton.dart';

class registerscreen extends StatefulWidget {
  registerscreen({super.key});

  @override
  State<registerscreen> createState() => _registerscreenState();
}

late Size size;

class _registerscreenState extends State<registerscreen> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: myAppbar(title: "Register Your Account"),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            text("Name"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "Enter your name",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.name,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            text("Email"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "Please enter email",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            text("Mobile number"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "Please enter mobile number",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.phone,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            text("DOB"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                decoration: InputDecoration(
                  suffixIcon: Icon(
                    Icons.calendar_month_outlined,
                    color: Color(0xff838383),
                    size: 19,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "mm/dd/yyyy",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.datetime,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            text("Password"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  suffixIcon: Icon(
                    Icons.visibility_off_outlined,
                    color: Color(0xff838383),
                    size: 19,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "Enter password",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.visiblePassword,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            text("Confirm Password"),
            SizedBox(
              height: 5,
            ),
            Container(
              height: size.height * 0.055,
              child: TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  suffixIcon: Icon(
                    Icons.visibility_off_outlined,
                    color: Color(0xff838383),
                    size: 19,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: MyColor.BorderColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: MyColor
                          .BorderColor, // Color when the TextField is focused
                    ),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                  hintText: "Enter confirm password",
                  // Replace with a variable if needed
                  hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: "Poppins",
                    color: MyColor.HintColor,
                  ),
                ),
                keyboardType: TextInputType.phone,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            SizedBox(
              width: double.infinity,
              height: size.height * 0.06,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: MyColor.ButtonColor,
                  // Filled button color
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(11),
                  ),
                  elevation: 0, // Optional: Remove shadow if not needed
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => otpvarification()),
                  );
                },
                child: Text(
                  "Continue",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontFamily: "Poppins",
                  ),
                ),
              ),
            ),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => registerscreen()),
                      );
                    },
                    child: Text(
                      "Already  have an account ?",
                      style: TextStyle(
                        fontSize: 14,
                        fontFamily: "Poppins",
                        fontWeight: FontWeight.w500,
                        color: MyColor
                            .TextColor, // Optional: Change text color if needed
                      ),
                    ),
                  ),
                  Text(
                    "Login",
                    style: TextStyle(
                      color: MyColor.TextLinkColor,
                      fontFamily: "Poppins",
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget text(String? text) {
    return Text(
      text ?? '',
      style: TextStyle(
          fontFamily: "Poppins", color: MyColor.TextColor, fontSize: 14),
    );
  }
}
