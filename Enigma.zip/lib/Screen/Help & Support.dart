import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_assets.dart';

class HelpSupport extends StatefulWidget {
  HelpSupport({super.key});

  @override
  State<HelpSupport> createState() => _HelpSupportState();
}

late Size size;

class _HelpSupportState extends State<HelpSupport> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Colors.black,
            size: 18,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              "Help & Support",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w500,
                fontFamily: AppConstant.poppinsFont,
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Image(
            image: Helpsupport,
            height: size.height * 0.4,
          ),
          SizedBox(
            height: size.height * 0.07,
          ),
          Padding(
            padding: const EdgeInsets.only(
              left: 20.0,
              right: 20,
              bottom: 10,
            ),
            child: Row(
              children: [
                Icon(
                  Icons.call,
                  color: MyColor.ButtonColor,
                ),
                SizedBox(
                  width: size.width * 0.06,
                ),
                Text(
                  "Call",
                  style: TextStyle(
                    fontFamily: AppConstant.poppinsFont,
                  ),
                ),
              ],
            ),
          ),
          Divider(),
          Padding(
            padding:
                EdgeInsets.only(left: 20.0, right: 20, bottom: 20, top: 10),
            child: Row(
              children: [
                Icon(
                  Icons.email,
                  color: MyColor.ButtonColor,
                ),
                SizedBox(
                  width: size.width * 0.06,
                ),
                Text(
                  "Contact us on email",
                  style: TextStyle(
                    fontFamily: AppConstant.poppinsFont,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
