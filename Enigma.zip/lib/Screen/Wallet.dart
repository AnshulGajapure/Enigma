import 'dart:ui';

import 'package:enigma/resources/app_constants.dart';
import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/my_assets.dart';

class Wallet extends StatefulWidget {
  Wallet({super.key});

  @override
  State<Wallet> createState() => _WalletState();
}

final List<Map<String, dynamic>> transactions = [
  {
    "title": "Purchase",
    "date": "24 June 2024",
    "quantity": 25,
    "amount": "68,526.33"
  },
];
late Size size;

void _showPopup(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: true,
    builder: (BuildContext context) {
      return Stack(
        children: [
          // Blurred background
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              color: Colors.transparent.withOpacity(0.2),
            ),
          ),
          // Center popup
          Center(
            child: Container(
              width: size.width * 0.8,
              padding: EdgeInsets.only(left: 20, right: 20, bottom: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 2,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                      width: size.width * 0.05,
                      height: size.height * 0.05,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.black, // Button color
                            shape: CircleBorder(), // Circular shape
                            padding: EdgeInsets
                                .only() // Adjust padding to center the icon well
                            ),
                        child: Icon(
                          Icons.close,
                          color: Colors.white, // Icon color
                          size: 15, // Icon size
                        ),
                      )),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Transaction",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: MyColor.WalletpopupText,
                          fontWeight: FontWeight.w500,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "Purchase",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Date",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: MyColor.WalletpopupText,
                          fontWeight: FontWeight.w500,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "14 Dec 2024",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Purchase Plan",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: MyColor.WalletpopupText,
                          fontWeight: FontWeight.w500,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "Gold",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w600,
                          color: MyColor.TradeRedText,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Amount",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: MyColor.WalletpopupText,
                          fontWeight: FontWeight.w500,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "Rs. 200",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Coins Credited",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: MyColor.WalletpopupText,
                          fontWeight: FontWeight.w500,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      Text(
                        "10000",
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: size.height * 0.015,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    },
  );
}

class _WalletState extends State<Wallet> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Padding(
        padding: const EdgeInsets.only(top: 60, left: 15, right: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "My Wallet",
              style: TextStyle(
                  fontSize: size.height * 0.023,
                  fontFamily: AppConstant.poppinsFont,
                  fontWeight: FontWeight.w600),
            ),
            SizedBox(
              height: size.height * 0.01,
            ),
            GestureDetector(
              onTap: () => _showPopup(context), // Show popup on tap
              child: Container(
                height: size.height * 0.16,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: MyColor.WalletContainer),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Wallet Balance",
                      style: TextStyle(
                          fontSize: size.height * 0.021,
                          fontFamily: AppConstant.poppinsFont,
                          fontWeight: FontWeight.w500,
                          color: Colors.white),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.currency_rupee,
                          color: Colors.white,
                          size: size.height * 0.037,
                        ),
                        Text(
                          '1,00,000',
                          style: TextStyle(
                            fontSize: size.height * 0.037,
                            // fontWeight: FontWeight.bold,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            fontFamily: AppConstant.poppinsFont,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: size.height * 0.01,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: size.height * 0.1,
                  width: size.width * 0.43,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: MyColor.WalletContainer1),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Available Balance',
                        style: TextStyle(
                          fontSize: size.height * 0.02,
                          // fontWeight: FontWeight.bold,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      SizedBox(
                        height: size.height * 0.01,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            color: Colors.white,
                            size: size.height * 0.02,
                          ),
                          Text(
                            '80,000',
                            style: TextStyle(
                              fontSize: size.height * 0.02,
                              // fontWeight: FontWeight.bold,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  height: size.height * 0.1,
                  width: size.width * 0.43,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: MyColor.WalletContainer,
                    image: DecorationImage(
                      image: Wattetcontainer, // Replace with your image path
                      fit: BoxFit
                          .cover, // Adjust this based on how you want the image to fit
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Used Balance',
                        style: TextStyle(
                          fontSize: size.height * 0.02,
                          // fontWeight: FontWeight.bold,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                      SizedBox(
                        height: size.height * 0.01,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            color: Colors.white,
                            size: size.height * 0.02,
                          ),
                          Text(
                            '20,000',
                            style: TextStyle(
                              fontSize: size.height * 0.02,
                              // fontWeight: FontWeight.bold,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: size.height * 0.018,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "All Coins",
                  style: TextStyle(
                    fontSize: size.height * 0.018,
                    // fontWeight: FontWeight.bold,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                    fontFamily: AppConstant.poppinsFont,
                  ),
                ),
                Text(
                  "View All",
                  style: TextStyle(
                    fontSize: size.height * 0.018,
                    // fontWeight: FontWeight.bold,
                    fontWeight: FontWeight.w500,
                    color: MyColor.IndexText,
                    fontFamily: AppConstant.poppinsFont,
                  ),
                )
              ],
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 18),
                itemCount: transactions.length,
                itemBuilder: (context, index) {
                  final transaction = transactions[index];
                  return Container(
                    margin: EdgeInsets.only(bottom: size.height * 0.01),
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 5,
                          spreadRadius: 2,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              transaction["title"],
                              style: TextStyle(
                                fontSize: size.height * 0.019,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppConstant.poppinsFont,
                                color: Colors.black,
                              ),
                            ),
                            Text(
                              transaction["quantity"].toString(),
                              style: TextStyle(
                                fontSize: size.height * 0.019,
                                fontWeight: FontWeight.w400,
                                fontFamily: AppConstant.poppinsFont,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: size.height * 0.02),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              transaction["date"],
                              style: TextStyle(
                                fontSize: size.height * 0.014,
                                fontWeight: FontWeight.w400,
                                fontFamily: AppConstant.poppinsFont,
                                color: Colors.black,
                              ),
                            ),
                            Text(
                              transaction["amount"],
                              style: TextStyle(
                                fontSize: size.height * 0.014,
                                fontWeight: FontWeight.w400,
                                fontFamily: AppConstant.poppinsFont,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
