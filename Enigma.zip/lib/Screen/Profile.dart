import 'package:enigma/resources/my_colors.dart';
import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import 'Edit_Profile.dart';
import 'Help & Support.dart';

late Size size;

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          CustomPaint(
            size: Size(size.width, size.height * 0.35),
            painter: CurvePainter(),
          ),
          Column(
            children: [
              Container(
                height: size.height * 0.4,
                child: Stack(
                  children: [
                    Positioned(
                      top: 50,
                      right: 20,
                      child: InkWell(
                        onTap: () {},
                        child: Row(
                          children: [
                            Icon(
                              Icons.logout,
                              color: Colors.white,
                              size: 25,
                            ),
                            SizedBox(width: 8),
                            Text(
                              "Logout",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontFamily: AppConstant.poppinsFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 30,
                      left: size.width / 2 - 50,
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundImage:
                                AssetImage('assets/images/profile_pic.jpg'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  Text(
                    "Pramod Sharma",
                    style: TextStyle(
                      fontSize: size.height * 0.026,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstant.poppinsFont,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    "pramod@maxtra.com | +91 8076774545",
                    style: TextStyle(
                      fontSize: 12,
                      fontFamily: AppConstant.poppinsFont,
                      color: Colors.black,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Container(
                    width: size.width * 0.51,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  EditProfile()), // Navigate to ProfilePage
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: MyColor.ButtonColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        elevation: 4,
                        padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.edit, size: 20, color: Colors.white),
                          SizedBox(width: 8),
                          Text(
                            "Edit",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: AppConstant.poppinsFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
                child: Container(
                  width: size.width,
                  // height: size.height * 0.02,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        offset: Offset(0, 4),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(30.0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(Icons.thumb_up_alt_outlined,
                                color: MyColor.ButtonColor),
                            SizedBox(width: size.width * 0.01),
                            Text(
                              "Purchase Plan",
                              style: TextStyle(
                                fontSize: size.height * 0.016,
                                fontWeight: FontWeight.w500,
                                fontFamily: AppConstant.poppinsFont,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      HelpSupport()), // Replace with your target page
                            );
                          },
                          child: Row(
                            children: [
                              Icon(Icons.question_mark_rounded,
                                  color: MyColor.ButtonColor),
                              SizedBox(width: size.width * 0.01),
                              Text(
                                "Help & Support",
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            Icon(Icons.description_outlined,
                                color: MyColor.ButtonColor),
                            SizedBox(width: size.width * 0.01),
                            Text("Terms & Conditions",
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            Icon(Icons.local_police_outlined,
                                color: MyColor.ButtonColor),
                            SizedBox(width: size.width * 0.01),
                            Text("Privacy policy",
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            Icon(Icons.thumb_up_alt_outlined,
                                color: MyColor.ButtonColor),
                            SizedBox(width: size.width * 0.01),
                            Text("Submit Review",
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            Icon(Icons.lock_outlined,
                                color: MyColor.ButtonColor),
                            SizedBox(width: size.width * 0.01),
                            Text("Change Password",
                                style: TextStyle(
                                  fontSize: size.height * 0.016,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class CurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = MyColor.ButtonColor
      ..style = PaintingStyle.fill;
    Path path = Path();
    path.lineTo(0, size.height * 0.75);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.75);
    path.lineTo(size.width, 0);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
