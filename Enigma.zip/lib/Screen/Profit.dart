import 'package:flutter/material.dart';

import '../resources/app_constants.dart';
import '../resources/my_assets.dart';
import '../resources/my_colors.dart';
import 'Wallet.dart';

class Profit extends StatefulWidget {
  Profit({super.key});

  @override
  State<Profit> createState() => _ProfitState();
}

late Size size;

class Stock {
  final String name;
  final double buyAvg;
  final int qty;
  final double sellAvg;
  final double profitLoss;

  Stock({
    required this.name,
    required this.buyAvg,
    required this.qty,
    required this.sellAvg,
    required this.profitLoss,
  });
}

class _ProfitState extends State<Profit> {
  List<Stock> stockList = [
    Stock(name: "CIPLA", buyAvg: 100, qty: 50, sellAvg: 120, profitLoss: 1000),
    Stock(name: "AAPL", buyAvg: 130, qty: 30, sellAvg: 150, profitLoss: 600),
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      body: Padding(
        padding: EdgeInsets.only(top: 50.0, left: 15, right: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Wallet()),
                );
              },
              child: Image(
                image: back,
                height: size.height * 0.03,
              ),
            ),
            SizedBox(
              height: size.height * 0.02,
            ),
            Container(
              height: size.height * 0.12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: MyColor.WalletContainer,
                image: DecorationImage(
                  image: container, // Replace with your image path
                  fit: BoxFit.cover,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "P&L",
                    style: TextStyle(
                      fontSize: size.height * 0.021,
                      fontFamily: AppConstant.poppinsFont,
                      fontWeight: FontWeight.w500,
                      color: Colors.white70,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '+ 2520.96',
                        style: TextStyle(
                          fontSize: size.height * 0.036,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontFamily: AppConstant.poppinsFont,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: size.height * 0.02,
            ),
            Flexible(
              child: Container(
                padding: EdgeInsets.only(
                  right: 10,
                  left: 10,
                ),
                decoration: BoxDecoration(
                    color: MyColor.Container,
                    borderRadius: BorderRadius.circular(10)),
                child: ListView.builder(
                  padding: EdgeInsets.only(top: 15),
                  itemCount: stockList.length,
                  itemBuilder: (context, index) {
                    Stock stock = stockList[index];
                    return Container(
                      padding: EdgeInsets.only(
                          right: 15, left: 15, top: 10, bottom: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 5,
                            spreadRadius: 2,
                            offset: Offset(0, 0),
                          ),
                        ],
                      ),
                      margin: EdgeInsets.only(bottom: 10),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                stock.name,
                                style: TextStyle(
                                  fontSize: size.height * 0.021,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: AppConstant.poppinsFont,
                                  color: Colors.black,
                                ),
                              ),
                              Row(
                                children: [
                                  Text(
                                    "Buy Avg.",
                                    style: TextStyle(
                                      fontSize: size.height * 0.012,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  SizedBox(
                                    width: size.width * 0.01,
                                  ),
                                  Text(
                                    stock.buyAvg.toString(),
                                    style: TextStyle(
                                      fontSize: size.height * 0.021,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    "Qty.",
                                    style: TextStyle(
                                      fontSize: size.height * 0.013,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  SizedBox(
                                    width: size.width * 0.01,
                                  ),
                                  Text(
                                    stock.qty.toString(),
                                    style: TextStyle(
                                      fontSize: size.height * 0.021,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    "Sell Avg.",
                                    style: TextStyle(
                                      fontSize: size.height * 0.013,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  SizedBox(
                                    width: size.width * 0.01,
                                  ),
                                  Text(
                                    stock.sellAvg.toString(),
                                    style: TextStyle(
                                      fontSize: size.height * 0.021,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: size.height * 0.036,
                                width: size.width * 0.22,
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.of(context)
                                        .pop(); // Close the popup
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: MyColor.GreenButton,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                  child: Text(
                                    "Buy",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: size.height * 0.017,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                    ),
                                  ),
                                ),
                              ),
                              Row(
                                children: [
                                  Text(
                                    "P&L",
                                    style: TextStyle(
                                      fontSize: size.height * 0.013,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  SizedBox(
                                    width: size.width * 0.01,
                                  ),
                                  Text(
                                    "+${stock.profitLoss} ",
                                    style: TextStyle(
                                      fontSize: size.height * 0.021,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: MyColor.IndexText,
                                    ),
                                  ),
                                  SizedBox(
                                    width: size.width * 0.01,
                                  ),
                                  Text(
                                    "coins",
                                    style: TextStyle(
                                      fontSize: size.height * 0.013,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: AppConstant.poppinsFont,
                                      color: MyColor.IndexText,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
