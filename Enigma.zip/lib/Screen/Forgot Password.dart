import 'package:flutter/material.dart';

import '../resources/my_colors.dart';
import '../utils/my_appbar.dart';
import 'Create Password.dart';

class ForgotPassword extends StatefulWidget {
  ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

late Size size;

class _ForgotPasswordState extends State<ForgotPassword> {
  final TextEditingController mobileNumberController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  void dispose() {
    mobileNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: MyColor.BackgroundColor,
      appBar: myAppbar(title: 'Forgot Password'),
      body: Padding(
        padding: EdgeInsets.only(left: 15, right: 15, top: 35),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Please enter your registered Mobile Number",
                  style: TextStyle(
                      fontSize: size.height * 0.022,
                      color: MyColor.TextColor,
                      fontFamily: "Poppins"),
                ),
                SizedBox(
                  height: size.height * 0.07,
                ),
                text("Mobile Number"),
                SizedBox(
                  height: size.height * 0.01,
                ),
                Container(
                  height: size.height * 0.06,
                  child: TextFormField(
                    controller: mobileNumberController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: MyColor.BorderColor, width: 1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: MyColor
                              .BorderColor, // Color when the TextField is focused
                        ),
                      ),
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 2.0, horizontal: 10.0),
                      hintText: "Enter mobile number",
                      errorStyle: TextStyle(
                        fontSize: size.height * 0.018,
                        height: 0.3,
                      ),
                      hintStyle: TextStyle(
                        fontSize: size.height * 0.018,
                        fontFamily: "Poppins",
                        color: MyColor.HintColor,
                      ),
                    ),
                    keyboardType: TextInputType.name,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Mobile number is required';
                      } else if (!RegExp(r'^\d{10}$').hasMatch(value)) {
                        return 'Enter a valid 10-digit mobile number';
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: size.height * 0.25,
                ),
                SizedBox(
                  width: double.infinity,
                  height: size.height * 0.06,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: MyColor.ButtonColor,
                      // Filled button color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(11),
                      ),
                      elevation: 0, // Optional: Remove shadow if not needed
                    ),
                    onPressed: () {
                      // if (_formKey.currentState!.validate()) {
                      //   ScaffoldMessenger.of(context).showSnackBar(
                      //     SnackBar(content: Text('Processing...')),
                      //   );
                      // }
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreatePassword()),
                      );
                    },
                    child: Text(
                      "Send",
                      style: TextStyle(
                        fontSize: size.height * 0.022,
                        color: Colors.white,
                        fontFamily: "Poppins",
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: size.height * 0.01,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Back Login",
                      style: TextStyle(
                        color: MyColor.TextLinkColor,
                        fontFamily: "Poppins",
                        fontSize: size.height * 0.017,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget text(String? text) {
    return Text(
      text ?? '',
      style: TextStyle(
        fontFamily: "Poppins",
        color: MyColor.TextColor,
        fontSize: size.height * 0.020,
      ),
    );
  }
}
